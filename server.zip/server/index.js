// Import required modules
import express from "express";
import cors from "cors";

// Initialize the app
const app = express();
app.use(cors());
app.use(express.json()); // To handle JSON requests

// Sample Users (for reference)
const users = [
  {
    id: 0,
    email: "student@example.com",
    name: "John",
    password: "12345678",
    role: "student",
    department: "Computer Science",
  },
  {
    id: 1,
    email: "admin@example.com",
    name: "Adam",
    password: "12345678",
    role: "admin",
    department: "Computer Science",
  },

  {
    id: 2,
    email: "admin2@example.com",
    name: "Kurt",
    password: "12345678",
    role: "admin",
    department: "Physics",
  },
  {
    id: 3,
    email: "student@example2.com",
    name: "Drew",
    password: "12345678",
    role: "student",
    department: "Physics",
  },
  {
    id: 4,
    email: "owner@example.com",
    name: "Vince",
    password: "owner123",
    role: "owner",
  },
  {
    id: 5,
    email: "student@example3.com",
    name: "Seth",
    password: "12345678",
    role: "student",
    department: "Physics",
  },
];

// Sample Departments
const departments = [
  { id: 0, name: "Computer Science" },
  { id: 1, name: "Physics" },
];

// Dummy Attendance Records
const attendanceRecords = [
  {
    studentId: 0,
    email: "student@example.com",
    department: "Computer Science",
    date: "2024-10-01",
    status: "present",
  },
  {
    studentId: 0,
    email: "student@example.com",
    department: "Computer Science",
    date: "2024-10-02",
    status: "absent",
  },
  {
    studentId: 4,
    email: "student@example2.com",
    department: "Physics",
    date: "2024-10-01",
    status: "present",
  },
  {
    studentId: 4,
    email: "student@example2.com",
    department: "Physics",
    date: "2024-10-02",
    status: "present",
  },
];

// Endpoint to get users
app.get("/api/users", (req, res) => {
  res.send(users);
});

// Endpoint to get departments
app.get("/api/departments", (req, res) => {
  res.send(departments);
});

// Attendance Endpoint
// POST endpoint to mark attendance for a student
app.post("/api/attendance", (req, res) => {
  const { studentId, date, status } = req.body;
  const newRecord = { studentId, date, status };

  attendanceRecords.push(newRecord);
  res
    .status(201)
    .send({ message: "Attendance recorded successfully", newRecord });
});

// GET endpoint to fetch attendance records for a student
// Attendance Endpoint
// GET endpoint to fetch attendance records
app.get("/api/attendance", (req, res) => {
  const { studentId } = req.query;

  if (studentId) {
    // Parse studentId as integer and filter attendance records for this student
    const filteredRecords = attendanceRecords.filter(
      (record) => record.studentId === parseInt(studentId)
    );
    res.send(filteredRecords);
  } else {
    // If no studentId is provided, return all attendance records
    res.send(attendanceRecords);
  }
});

// Add to your server (index.js)

// Endpoint to create a new department with an admin
// Endpoint to create a new department with an admin
app.post("/api/departments", (req, res) => {
  const { name, email, password } = req.body;

  // Check if the department already exists
  const existingDepartment = departments.find((dept) => dept.name === name);
  if (existingDepartment) {
    return res.status(400).send({ error: "Department already exists." });
  }

  // Create new department ID
  const departmentId = departments.length;

  // Add department
  const newDepartment = { id: departmentId, name };
  departments.push(newDepartment);

  // Add admin user for the department
  const newAdmin = {
    id: users.length,
    email,
    password,
    role: "admin",
    department: name,
  };
  users.push(newAdmin);

  res.status(201).send({
    message: "Department and Admin created successfully",
    department: newDepartment,
    admin: newAdmin,
  });
});

// Start the server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
